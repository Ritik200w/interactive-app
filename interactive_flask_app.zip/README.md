# Interactive Flask App for Elastic Beanstalk

## Features
- Interactive form for user greeting
- AJAX-based current time fetch
- Bootstrap frontend styling
- Gunicorn for production

## Run Locally
```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python application.py
```

## Deploy to Elastic Beanstalk
```bash
eb init -p python-3.11 interactive-flask-app
eb create interactive-env
eb deploy
```
