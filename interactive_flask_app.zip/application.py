from flask import Flask, render_template, request, jsonify
import os
import datetime

app = Flask(__name__)

@app.route('/')
def index():
    return render_template("index.html")

@app.route('/greet', methods=['POST'])
def greet():
    name = request.form.get("name", "Guest")
    return jsonify({"message": f"Hello, {name}! Welcome to the interactive Flask app."})

@app.route('/time')
def get_time():
    return jsonify({"time": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")})

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port)
